<?php 
namespace  Config;
class Db{
    public static $chat = array(
        'host'    => '127.0.0.1',
        'port'    => 3306,
        'user'    => 'root',
        'password' => '123456',
        'dbname'  => 'sys',
        'charset'    => 'utf8',
    );
}