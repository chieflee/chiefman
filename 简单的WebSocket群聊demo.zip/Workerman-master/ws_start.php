<?php
/**
 * Created by PhpStorm.
 * User: yzq6431
 * Date: 17/5/19
 * Time: 下午10:12
 */
use Workerman\Worker;
require_once __DIR__."/Autoloader.php";

$work=new Worker("websocket://0.0.0.0:888");

$work->count=4;//把所有用户全部放进一个进程 以便处理群发消息到当前进程的所有用户!!
$user_data=array();//储存单个用户资料
$work->onMessage=function ($connection,$data){
    global $user_data;
    global $work;//获取进程的信息
    $user_data[$connection->id]['connection']=$connection;//储存当前链接进来用户的握手信息
    if(!empty($user_data[$connection->id]['username'])){
        foreach ($user_data as $value){
            $value['connection']->send("用户".$user_data[$connection->id]['username']."发送消息:".$data);
        }
    }else{
        $user_data[$connection->id]['username']=$data;//储存用户第一次进来的用户名
        foreach ($user_data as $value){//发送用户链接进来的信息给所有用户
            if($value['connection']->id==$connection->id){
                $value['connection']->send("欢迎用户:".$data."进入群,当前人数过多!你被系统自动分配到进程".$work->id."聊天群里!");
            }else{
                $value['connection']->send("欢迎用户:".$data."进入群!");
            }
        }
    }
};

Worker::runAll();